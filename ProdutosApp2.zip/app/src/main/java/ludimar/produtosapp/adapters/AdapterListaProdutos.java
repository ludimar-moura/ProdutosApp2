package ludimar.produtosapp.adapters;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import ludimar.produtosapp.model.Produto;

/**
 * Created by Computador on 04/10/2018.
 */

public class AdapterListaProdutos extends BaseAdapter {

    private Context context;
    private List<Produto> produtoList;

    public AdapterListaProdutos(Context context, List<Produto> produtoList) {
        this.context = context;
        this.produtoList = produtoList;
    }

    @Override
    public int getCount() {

        return this.produtoList.size();
    }

    @Override
    public Object getItem(int posicao) {
        return this.produtoList.get(posicao);
    }

    @Override
    public long getItemId(int position) {
        return posicao;
    }

    public void renoverProduto(int posicao){

        this.produtoList.remover(posicao);
        notifyDataSetChanged();

    }

    @Override
    public View getView(int posicao, View convertView, ViewGroup parent) {
        View v = View.inflate(this.context, R.layout.layout_produto, root: null)

        TextView tvNomeProduto = (TextView) v.findViewById(R.id.tvNomeProduto);
        TextView tvPrecoProduto = (TextView) v.findViewById(R.id.tvPrecoProduto);
        TextView tvEstoqueProduto = (TextView) v.findViewById(R.id.tvEstoqueProduto);

        tvNomeProduto.setText(this.produtoList.get(posicao).getNome());
        tvPrecoProduto.setText(String.valueOf (this.produtoList.get(posicao).getNome()));
        tvEstoqueProduto.setText(String.valueOf(this.produtoList.get(posicao).getNome()));

        return v;
    }
}
