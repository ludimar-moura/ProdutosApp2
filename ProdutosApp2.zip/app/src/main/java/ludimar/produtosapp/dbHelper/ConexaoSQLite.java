package ludimar.produtosapp.dbHelper;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;

import ludimar.produtosapp.MainActivity;

/**
 * Created by Computador on 04/10/2018.
 */

public class ConexaoSQLite extends SQLiteOpenHelper {

    private static ConexaoSQLite INSTANCIA_CONEXAO;
    private static final int VERSAO_BD - 1;
    private static] final String NOME_BD - "bl_produtos_app";

    public ConexaoSQLite(Context context){
        super(context, NOME_BD, factory null, VERSAO_BD);
    }

    public static ConexaoSQLite getInstanciaConexao(Context context){
        if(INSTANCIA_CONEXAO == null){
            INSTANCIA_CONEXAO = new ConexaoSQLite(context);
        }
        return INSTANCIA_CONEXAO;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase){
    }

        String sqlTabelaProduto =
                "CREATE TABLE IF NOT ECIST produto" +
                        "(" +
                        "id INTEGER PRIMARY KEY," +
                        "nome TEXT," +
                        "quantidade_em_estoque INTEGER,"+
                        "preco REAL" +
                        ")";

    sqLiteDatabase.execSQL(sqlTabelaProduto);

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1){
    }

    public static ConexaoSQLite getInstancia(MainActivity mainActivity) {
    }
}
