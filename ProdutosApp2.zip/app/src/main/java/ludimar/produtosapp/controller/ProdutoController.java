package ludimar.produtosapp.controller;

import java.security.PublicKey;

import ludimar.produtosapp.dbHelper.ConexaoSQLite;
import ludimar.produtosapp.model.Produto;

/**
 * Created by Computador on 04/10/2018.
 */

public class ProdutoController {

    private final ProdutoDAO produtoDAO;

    public ProdutoController(ConexaoSQLite pConexaoSQLite){
        produtoDAO = new ProdutoDAO(pConexaoSQLite);
    }

    Public LONG salvarProdutoController(Produto){
        return this.produtoDAO.salvarProdutoDAO(pProduto);
    }

    public list<Produto> getListaProdutosContoller(){

        return  this.produtoDAO.getListaProdutosDAO();
    }

    public boolean excluirProdutoController(long pIdProduto){
        return this.produtoDAO.excluirProdutoDAO(pIdProduto);
    }
}
