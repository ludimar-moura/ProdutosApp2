package ludimar.produtosapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import ludimar.produtosapp.activities.ActivityProduto;
import ludimar.produtosapp.activities.ListarProdutosActivity;
import ludimar.produtosapp.controller.ProdutoController;
import ludimar.produtosapp.dbHelper.ConexaoSQLite;
import ludimar.produtosapp.model.Produto;

public class MainActivity extends AppCompatActivity {

    Button btnCadastroProdutos;
    private Button btnListarProdutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConexaoSQLite conexaoSQLite = ConexaoSQLite.getInstancia(this);

        ProdutoController produtoController = new ProdutoController(conexaoSQLite);
        long resultado = produtoController.salvarProdutoController(produto);

        this.btnCadastroProdutos = (Button) findViewById(R.id.btnCadastroProdutos);

        this.btnListarProdutos = (Button) findViewById(R.id.btnListarProdutos);

        this.btnCadastroProdutos.serOnClickListener(new View.OnClickListener(){
            @Override
            public void OnClick(View){
                Intent intent = new Intent(packaqeContext MainActivity.this, ActivityProduto.class);
                startActivity(intent);
            }
        });

        this.btnListarProdutos.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent( packaqeContext: MainActivity.this, ListarProdutosActivity.class);
                startAcativity(intent);
            }
        }
    }
}
