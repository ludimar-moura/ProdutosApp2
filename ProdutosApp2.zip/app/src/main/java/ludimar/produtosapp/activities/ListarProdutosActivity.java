package ludimar.produtosapp.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import ludimar.produtosapp.R;
import ludimar.produtosapp.adapters.AdapterListaProdutos;
import ludimar.produtosapp.controller.ProdutoController;
import ludimar.produtosapp.dbHelper.ConexaoSQLite;
import ludimar.produtosapp.model.Produto;

public class ListarProdutosActivity extends AppCompatActivity {

    private ListView lsvProdutos;
    private List<Produto> produtoList;
    private AdapterListaProdutos adapterListaProdutos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_produtos);

        final ProdutoController produtoController = new ProdutoController(ConexaoSQLite.getInstancia(ListarProdutosActivity.this));
        produtoList = produtoController.getListaProdutosContoller();


        this.lsvProdutos = (ListView) findViewById(R.id.lsvProdutos);

        this.adapterListaProdutos = new AdapterListaProdutos(context: ListarProdutosActivity.this, this.produtoList);

        this.lsvProdutos.setAdapter(this.adapterListaProdutos);

        this.lsvProdutos.setOnClickListener(new AdapterView.OnClickListener(){

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int posicao, long id){

                final Produto produtoSelecionado = (Produto) AdapterListaProdutos.getItem(posicao);

                AlertDialog.Builder janelaDeEscolha = new AlertDialog.Builder(context: listarProdutoActivity.this);

                janelaDeEscolha.setTitle("Escolha:");
                janelaDeEscolha.setMessage("O que deseja fazer com o produto selecionado ?");
                janelaDeEscolha.setNeutralButton("Cancelar", new DialogInterface.onClickListener(){
                    @Override
                    public void onClick(DialogInterface, int id){
                        dialogInterface.cancel();
                    }

                });

                janelaDeEscolha.setNegativeButton("Excluir", new DialogInterface.onClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int id){

                               boolean excluiu = produtoController.excluirProdutoController(produtoSelecionado.getId());

                                dialogInterface.cancel();

                                if(excluiu == true){

                                    adapterListaProdutos.renoverProduto(posicao);

                                    Toast.makeText(context: ListarProdutosActivity.this, text: "Produto excluido com sucesso...", Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(context: ListarProdutosActivity.this, text: "ERRO ao excluir o produto...", Toast.LENGTH_SHORT).show();

                                }
                            }
                        });

                janelaDeEscolha.setPositiveButton("Editar", new DialogInterface.onClickListener(){
                    @Override
                    public void onClick(DialogInterface, int id){

                        Bundle bundleDadosProduto = new Bundle();

                        bundleDadosProduto.putLong("id_produto", produtoSelecionado.getId());
                        bundleDadosProduto.putString("nome_produto", produtoSelecionado.getNome());
                        bundleDadosProduto.putDouble("preco_produto", produtoSelecionado.getPreço());
                        bundleDadosProduto.putInt("estoque_produto", produtoSelecionado.getQuantidadeEstoque()));

                        Intent intentEditarProduto = new Intent(ListarProdutosActivity.this, EditarProdutosActivity.class);
                        intentEditarProduto.putExtra(bundleDadosProduto);
                        startActivity(intentEditarProduto);

                    }
                });

                janelaDeEscolha.create().show();

                Toast.makeText(context: lsvProdutosActivity.this, "Produto: " + produtoSelecionado.getNome(), Toast.LENGTH_SHORT.show());
            }
        });


    }
}
