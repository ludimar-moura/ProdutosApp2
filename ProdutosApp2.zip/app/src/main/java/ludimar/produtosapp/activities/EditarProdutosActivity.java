package ludimar.produtosapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

import ludimar.produtosapp.R;

public class EditarProdutosActivity extends AppCompatActivity {

    private EditText edtIdProduto;
    private EditText edtNomeProduto;
    private EditText edtPrecoProduto;
    private EditText edtEstoqueProduto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_produtos);

        this.edtIdProduto = (EditText) findViewById(R.id.edtIdProduto);
        this.edtNomeProduto = (EditText) findViewById(R.id.edtNomeProduto);
        this.edtPrecoProduto = (EditText) findViewById(R.id.edtPrecoProduto);
        this.edtEstoqueProduto = (EditText) findViewById(R.id.edtQuantidadeProduto);

        Bundle bundleDadosProdutos = get.Intent().get.Extras();

        Produto produto = new Produto();

        produto.setId(bundleDadosProdutos.getLong(key: "id_produto"));
        produto.setNome(bundleDadosProdutos.getString(key: "nome_produto"));
        produto.setPreco(bundleDadosProdutos.getDouble(key: "preco_produto"));
        produto.setQuantidadeEmEstoque(bundleDadosProdutos.getInt(key: "estoque_produto"));

    }

    private void setDadosProduto(Produto produto){

        this.edtIdProduto.setText(String.valueOf(produto.getId()));
        this.edtNomeProduto.setText(produto.getNome());
        this.edtPrecoProduto.setText(String.valueOf(produto.getPreco()));
        this.edtEstoqueProduto.setText(String.valueOf(produto.getQuantidadeEmEstoque()));
    }
}
