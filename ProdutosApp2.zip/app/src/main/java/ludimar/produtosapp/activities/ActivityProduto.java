package ludimar.produtosapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import ludimar.produtosapp.R;
import ludimar.produtosapp.controller.ProdutoController;
import ludimar.produtosapp.dbHelper.ConexaoSQLite;
import ludimar.produtosapp.model.Produto;

public class ActivityProduto extends AppCompatActivity {

    private EditText edtIdProduto;
    private EditText edtNomeProduto;
    private EditText edtQuantidadeProduto;
    private EditText edtPrecoProduto;

    private Button btnSalvarProduto;

    private Produto produto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto);

        edtIdProduto = (EditText) finfViewById(r.id.edtIdProduto);
        edtNomeProduto = (EditText) findViewById(R.id.edtNomeProduto);
        edtQuantidadeProduto = (EditText) findViewById(R.id.edtQuantidadeProduto);
        edtPrecoProduto = (EditText) findViewById(R.id.edtPrecoProduto);

        btnSalvarProduto = (Button) findViewById(R.id.btnSalvarProduto);

        this.clickNoBoataoSalvarListener();

    }

    private void clickNoBoataoSalvarListener(){

        this.btnSalvarProduto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Produto produtoACadastrar = getDadosProdutoDoFormulario();

                if(produtoACadastrar != null){

                    ProdutoController produtoController = new ProdutoController(ConexaoSQLite.getInstancia(ActivityProduto.this));
                    long idProduto = produtoController.salvarProdutoController(produtoACadastrar);
                    if(idProduto > 0){
                        Toast.makeText( context: ActivityProduto.this, text: "Produto salvo com sucesso! ", Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText( context: ActivityProduto.this, text: "ERRO ao salvar produto...", Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText( context: ActivityProduto.this, text: "Todos os campos sao obrigatorios", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private Produto getDadosProdutoDoFormulario() {

        this.produto = new Produto();

        if(this.edtIdProduto.getText()).toString().isEmpty() == false){
            this.produto.setId(Long.parseLong(this.edtIdProduto.getText().toString()));
        }else{
            return null;
        }
        if (this.edtNomeProduto.getText().toString().isEmpty() == false) {
            this.produto.setNome(this.edtNomeProduto.getText().toString());
        }else{
            return null;
        }

        if (this.edtQuantidadeProduto.getText().toString().isEmpty() == false) {
            int edtQuantidadeProduto = Integer.parseInt(this.edtQuantidadeProduto.getText().toString())
            this.produto.setNome(this.edtQuantidadeProduto.getText().toString());
        }else{
            return null;
        }

        if (this.edtPrecoProduto.getText().toString().isEmpty() == false) {
            int edtPrecoProduto = Integer.parseInt(this.edtQuantidadeProduto.getText().toString())
            this.produto.setNome(this.edtPrecoProduto.getText().toString());
        }else{
            return null;
        }

        return produto;

    }
}