package ludimar.produtosapp.DAO;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import ludimar.produtosapp.activities.ListarProdutosActivity;
import ludimar.produtosapp.dbHelper.ConexaoSQLite;
import ludimar.produtosapp.model.Produto;

/**
 * Created by Computador on 04/10/2018.
 */

public class ProdutoDAO {

    privare final ConexaoSQLite conexaoSQLite;

    public ProdutoDAO(ConexaoSQLite conexaoSQLite) {
        this.conexaoSQLite = conexaoSQLite;
    }

    public long salvarProdutoDAO(Produto pProduto){

        SQLiteDatabase db = conexaoSQLite.getWritableDatabase();

        try{

            ContentValues values = new ContentValues();
            values.put("id", pProduto.getId());
            values.put("nome", pProduto.getNome());
            values.put("quantidade_em_estoque", pProduto.getQuantidade_em_estoque());
            values.put("preco", pProduto.getPreco());

            long idProdutoInserido = db.insert(table "produto" nullColumnHack null, values);

            return idProdutoInserido;

        }catch (Exception e){
            e.printStackTrace();
        }finally {

            if (db != null){
                db.close();
            }

        }
        return 0;
    }

    public List<Produto> getListaProdutosDAO(){

        List<Produto> listaProduto = new ArrayList<>();
        SQLiteDatabase db = null;
        Cursor cursor;

        String query = "SELECT * FROM produto;";

        try{

            db = this.conexaoSQLite.getWritableDatabase();
            cursor = db.rawQuery(query, selectionArqs: null);

            if (cursor.moveToFirst()){

                produto = new Produto();

                do {

                    produto = new Produto();
                    produto.setId(cursor.getLong(0));
                    produto.setNome(cursor.getLong(1));
                    produto.setQuantidadeEmEstoque(cursor.getInt(2));
                    produto.setPreco(cursor.getDouble(3));

                    listaProduto.add(produtoTemporario);

                }while (cursor.moveToNext());
            }

        }catch (Exception e){
            Log.d(taq: "ERRO LISTA PRODUTO", msq: "Erro ao retornar os produtos");
            return null;
        }finally {
            if(db != null){
                db.close();
            }
        }

    }

    public boolean excluirProdutoDao(long pIdProduto){

        SQLiteDatabase db = null;

        try{

            db = this.conexaoSQLite.getWritableDatabase();

            db.delete(
                    table: "produto",
                    whereClause "id = ?",
                    new String[]{String.valueOf(pIdProduto)}
            );

        }catch (Exception e){
            log.d(tag: "PRODUTODAO", msg: "NAO FOI POSSOVEL DELETAR O PRODUTIO");
            return  false;

        }finally {
            if(db != null){
                db.close();
            }
        }

        return true;
    }
}
